package OOP_BY_EXAMPLE;

/*
public class Ex5_ElementCount {

		private String[] data;
		
		public Ex5_ElementCount(String[] myData) {
			this.data = myData;
		}
		
		public int howMany(String element) {
			int count = 0;
			for (int i=0; i < data.length -1; i++)
				if(data[i].equals(element))
					count++;
			return count;
		}
}
*/

public class Ex5_ElementCount {

	private Integer[] data;
	
	public Ex5_ElementCount(Integer[] myData) {
		this.data = myData;
	}
	
	public int howMany(Integer element) {
		int count = 0;
		for (int i=0; i < data.length; i++)
			if(data[i].equals(element))
				count++;
		return count;
	}
}
/*
public class Ex5_ElementCount<aType> {

	private aType[] data;
	
	public Ex5_ElementCount(aType[] myData) {
		this.data = myData;
	}
	
	public int howMany(aType element) {
		int count = 0;
		for (int i=0; i < data.length; i++)
			if(data[i].equals(element))
				count++;
		return count;
	}
}
*/