package OOP_BY_EXAMPLE;

public class Ex4_Employee {

		public static int nextID = 1;
		
		public int EIN;
		public String name;
		
		public Ex4_Employee(String name) {
			this.name = name;
			this.EIN = Ex4_Employee.nextID;
			nextID++;
		}
		
		public String toString() {
			return name + " --- " + this.EIN;
			
		}		
}
