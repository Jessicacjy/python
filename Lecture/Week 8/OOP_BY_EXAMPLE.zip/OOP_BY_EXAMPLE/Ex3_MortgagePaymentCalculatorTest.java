package OOP_BY_EXAMPLE;

public class Ex3_MortgagePaymentCalculatorTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Ex3_MortgagePaymentCalculator x = new Ex3_MortgagePaymentCalculator();
		double payment = x.calculateMonthlyPayment(150000, 15, 3.0);
		System.out.println(payment);
		
		Ex3_MortgagePaymentCalculator.calculateMonthlyPayment(150000, 15, 3.0);
		System.out.println(payment);

	}

}
