package OOP_BY_EXAMPLE;

public class Ex2_AbstractDemo {

	public static void main(String[] args) {
		
		// Animal x = new Animal();  //fails
		
		Cat c = new Cat();
		c.Talk();
		
		Animal c2 = new Cat(); // Polymorphism
		c2.Talk();
	}

}
abstract class Animal {   // try with no abstract
	abstract public void Talk();
}

class Cat extends Animal {
	public void Talk() { // try not to override
		System.out.println("Meow ...");
	}
}
