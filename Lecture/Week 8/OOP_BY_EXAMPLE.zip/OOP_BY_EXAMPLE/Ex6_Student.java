package OOP_BY_EXAMPLE;

public class Ex6_Student implements Comparable<Ex6_Student> {
	
	private String name;
	private int age;
	
	public Ex6_Student(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
	public String toString() {
		return this.name + "---" + this.age;
	}
	
	public int compareTo(Ex6_Student anotherStudent) {
		// TODO Auto-generated method stub
		int result;
		if (this.age == anotherStudent.age)
			result = 0;
		else if (this.age > anotherStudent.age)
			result = 1;
		else 
			result = -1;
		
		return result;
	}
	
	public boolean equals(Ex6_Student x) {
		return this.age == x.age;
	}
}
