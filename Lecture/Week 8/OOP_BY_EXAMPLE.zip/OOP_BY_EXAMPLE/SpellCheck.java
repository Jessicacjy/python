package OOP_BY_EXAMPLE;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.io.File;
import java.io.FileNotFoundException;

public class SpellCheck {

	public static void main(String[] args) 
			throws FileNotFoundException
	{
		Set<String> dictionaryWords = readWords("C:\\NWU\\MSiA 2017\\toGoW8\\dict.txt");
		Set<String> documentWords = readWords("C:\\NWU\\MSiA 2017\\toGoW8\\doc.txt");;

        // read in dictionary of words
        for (String word : documentWords) 
        {
            if (!dictionaryWords.contains(word))
            {
            	System.out.println(word);
            }
        }
	}
	
	public static Set<String> readWords(String filename) 
		throws FileNotFoundException
	{
		Set<String> words = new HashSet<String>();
		Scanner inp = new Scanner(new File(filename));
		inp.useDelimiter("[^a-zA-Z]+");
		while (inp.hasNext()) 
		{
			words.add(inp.next().toLowerCase());
		}
		inp.close();
		return words;
	}
}
