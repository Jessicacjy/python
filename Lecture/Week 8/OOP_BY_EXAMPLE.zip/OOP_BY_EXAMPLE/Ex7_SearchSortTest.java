package OOP_BY_EXAMPLE;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class Ex7_SearchSortTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] ar1 = {1,4,2,8,3,0,9};
		for (int i=0; i < ar1.length ; i++)
			System.out.print(ar1[i] + " ");
		System.out.println();
		Arrays.sort(ar1);
		for (int i=0; i < ar1.length ; i++)
			System.out.print(ar1[i] + " ");
		
		
		ArrayList<Integer> al = new ArrayList<Integer>();
		al.add(10);al.add(3);al.add(109);al.add(10);
		Collections.sort(al);
		System.out.println();
		System.out.println(al);
		
		ArrayList<String> al2 = new ArrayList<String>();
		al2.add("10");al2.add("3");al2.add("109");al2.add("10");
		Collections.sort(al2);
		System.out.println();
		System.out.println(al2);
		
		
		int[] a = {1,4,9};
		int v = 4;
		int pos = Arrays.binarySearch(a,v);
		System.out.println(pos);

		
		Country[] countries = new Country[3];
		countries[0] = new Country("ABC",300);
		countries[1] = new Country("XYZ",30);
		countries[2] = new Country("IJK",390);
		
		for (int i=0; i < countries.length ; i++)
			System.out.print(countries[i] + " ");
		System.out.println();
		Arrays.sort(countries);
		for (int i=0; i < countries.length ; i++)
			System.out.print(countries[i] + " ");
	}

}

class Country implements Comparable<Country>{
	private String name;
	private int populationInMil;
	
	public Country(String n, int i) {
		this.name = n;
		this.populationInMil = i;
	}
	
	public String toString() {
		return name + "--" + populationInMil;
	}
	
	public int compareTo(Country anotherCountry) {
		int result;
		if (this.populationInMil == anotherCountry.populationInMil)
			result = 0;
		else if (this.populationInMil > anotherCountry.populationInMil)
			result = 1;
		else 
			result = -1;
		
		return result;
	}
	
}
