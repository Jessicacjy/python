package OOP_BY_EXAMPLE;

/*
 * A test driver for Shape and its subclasses
 */

public class Ex1_TestShape {

	public static void main(String[] args) {
		Ex1_Rectangle r1 = new Ex1_Rectangle("red", 4, 5);  
		System.out.println(r1);  // Run Rectangle's toString()
		System.out.println("Area is " + r1.getArea());  // Run Rectangle's getArea()
		  
		Ex1_Triangle t1 = new Ex1_Triangle("blue", 4, 5);  
		System.out.println(t1);  // Run Triangle's toString()
		System.out.println("Area is " + t1.getArea());  // Run Triangle's getArea()
		
		
		// Polymorphism
		
		Ex1_Shape s1 = new Ex1_Rectangle("red", 4, 5);  // Upcast
		System.out.println(s1);  // Run Rectangle's toString()
		System.out.println("Area is " + s1.getArea());  // Run Rectangle's getArea()
		  
		Ex1_Shape s2 = new Ex1_Triangle("blue", 4, 5);  // Upcast
		System.out.println(s2);  // Run Triangle's toString()
		System.out.println("Area is " + s2.getArea());  // Run Triangle's getArea()
	}
}
