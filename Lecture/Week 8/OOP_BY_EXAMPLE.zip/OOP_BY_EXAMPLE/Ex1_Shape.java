package OOP_BY_EXAMPLE;

/*
 * Superclass Shape maintain the common properties of all shapes
 */
public class Ex1_Shape {
	   // Private member variable
	   private String color;
	   
	   // Constructor
	   public Ex1_Shape (String color) {
	      this.color = color;
	   }
	   
	   @Override
	   public String toString() {
	      return "Shape[color=" + color + "]";
	   }
	   
	   // All shapes must have a method called getArea().
	   public double getArea() {
	      // We have a problem here!
	      // We need to return some value to compile the program.
	      System.err.println("Shape unknown! Cannot compute area!");
	      return 0;
	   }
	}
