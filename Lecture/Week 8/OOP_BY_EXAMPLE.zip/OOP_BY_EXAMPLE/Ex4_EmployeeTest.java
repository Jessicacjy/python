package OOP_BY_EXAMPLE;

public class Ex4_EmployeeTest {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Ex4_Employee e1 = new Ex4_Employee("John");
		Ex4_Employee e2 = new Ex4_Employee("Jim");
		Ex4_Employee e3 = new Ex4_Employee("Alec");
		
		System.out.println(e1);
		System.out.println(e2);
		System.out.println(e3);
		System.out.println(Ex4_Employee.nextID);

	}
}
