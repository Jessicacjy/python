package OOP_BY_EXAMPLE;

public class Ex5_ElementCountTest {

	/*
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] myInput = {"aa","bb","ab","bb"};
		Ex5_ElementCount ec = new Ex5_ElementCount(myInput);
		
		System.out.println(ec.howMany("aa"));
		System.out.println(ec.howMany("bb"));
	}
	
	*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer[] myInput = {1,5,3,5,7};
		Ex5_ElementCount ec = new Ex5_ElementCount(myInput);
		
		System.out.println(ec.howMany(5));
		System.out.println(ec.howMany(7));
	}
	/*
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer[] myIntegerInput = {1,5,3,5,7};
		Ex5_ElementCount<Integer> ec1 = new Ex5_ElementCount<Integer>(myIntegerInput);		
		System.out.println(ec1.howMany(5));
		System.out.println(ec1.howMany(7));
		
		String[] myStringInput = {"aa","bb","ab","bb"};
		Ex5_ElementCount<String> ec2 = new Ex5_ElementCount<String>(myStringInput);
		
		System.out.println(ec2.howMany("aa"));
		System.out.println(ec2.howMany("bb"));
	}
	*/
}
