package OOP_BY_EXAMPLE;

public class Ex6_StudentTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Ex6_Student s1 = new Ex6_Student("Alec",18);
		Ex6_Student s2 = new Ex6_Student("Jim",21);
		Ex6_Student s3 = new Ex6_Student("Mary",8);
		
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
		
		if (s2.equals(s3))
			System.out.println("Yes");
		else
			System.out.println("No");
		
		System.out.println(s1.compareTo(s3));
		
		System.out.println("B".compareTo("B"));
	}
}
