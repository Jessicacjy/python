package LinkedList;

/**
A linked list is a sequence of nodes with efficient
element insertion and removal. This class 
contains a subset of the methods of the standard
java.util.LinkedList class.
*/
public class LinkedList
{  
private ListNode first;

/** 
   Constructs an empty linked list.
*/
public LinkedList()
{  
   first = null;
}

/**
   Returns the first element in the linked list.
   @return the first element in the linked list
*/
public String getFirst()
{  
   return first.data;
}

/**
   Removes the first element in the linked list.
   @return the removed element
*/
public void removeFirst()
{  
   first = first.next;
}

/**
   Adds an element to the front of the linked list.
   @param element the element to add
*/
public void addFirst(String element)
{  
	  ListNode newNode = new ListNode();
   newNode.data = element;
   newNode.next = first;
   first = newNode;
}

public void printIt()
{
	  ListNode iterator = first;
	  while (iterator != null)
	  {
	     System.out.print(iterator.data + " ");
	     iterator = iterator.next;
	  }
	  System.out.println();
}

//removeAtPos(int i)
//addAfetrPos(int i, String data)
}

class ListNode
{  
public String data;
public ListNode next;
}

