package MSiA;

import java.util.Scanner;

public class NumberGuess {
   public static void main(String[] args) {
      int secretNumber;     // Secret number to be guessed
      int numberIn;         // The guessed number entered
      int trialNumber = 0;  // Number of trials so far
      boolean done = false; // boolean flag for loop control
   
      // Set up the secret number
      // Math.random() generates a double in [0.0, 1.0)
      secretNumber = (int)(Math.random()*100);
   
      Scanner in = new Scanner(System.in);

      while (!done) {
         ++trialNumber;
         System.out.print("Enter your guess (between 0 and 99): ");
         numberIn = in.nextInt();
         if (numberIn == secretNumber) {
            System.out.println("Congratulation");
            done = true;
         } else if (numberIn < secretNumber) {
            System.out.println("Try higher");
         } else {
            System.out.println("Try lower");
         }
      }
      System.out.println("You got in " + trialNumber +" trials");
      in.close();
   }
}