package PQ;

public class Heap
{
   private static final int CAPACITY = 100;

   private int size;            // Number of elements in heap
   private Integer[] heap;     // The heap array

   public Heap()
   {
      size = 0;
      heap = new Integer[CAPACITY];
   }
 
   private void reheapify(int k)
   {
      Integer tmp = heap[k];
      int child;

      for(; 2*k <= size; k = child)
      {
         child = 2*k;

         if(child != size &&
            heap[child].compareTo(heap[child + 1]) > 0) child++;

         if(tmp.compareTo(heap[child]) > 0)  heap[k] = heap[child];
         else
                break;
      }
      heap[k] = tmp;
   }

 

 /**
  * Deletes the top item
  */
   public Integer deleteMin() 
   {
      
      Integer min = heap[1];
      heap[1] = heap[size--];
      reheapify(1);
      return min;
}

 /**
  * Inserts a new item
  */
   public void insert(Integer x)
   {
      

      //Insert a new item to the end of the array
      int pos = ++size;

      //Percolate up
      for(; pos > 1 && x < heap[pos/2]; pos = pos/2 )
         heap[pos] = heap[pos/2];

      heap[pos] = x;
   }
   

   public String toString()
   {
      String out = "";
      for(int k = 1; k <= size; k++) out += heap[k]+" ";
      return out;
   }

   public static void main(String[] args)
   {
      Heap h = new Heap();

      h.insert(10);
      h.insert(15);
      h.insert(6);
      h.insert(7);
      h.insert(5);
      h.insert(12);
      h.insert(17);
      System.out.println(h);
      System.out.println(h.deleteMin());
      System.out.println(h.deleteMin());
      System.out.println(h.deleteMin());
      System.out.println(h.deleteMin());
      System.out.println(h.deleteMin());
      System.out.println(h.deleteMin());

      System.out.println(h);

   }
}