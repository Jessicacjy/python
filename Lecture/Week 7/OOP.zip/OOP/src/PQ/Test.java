package PQ;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PriorityQ pq;
		
		pq = new PriorityQ();
		
		pq.insert(10);
		pq.insert(12);
		pq.insert(130);
		pq.insert(1120);
		pq.insert(130);
		
		pq.displayList();
	}

}
