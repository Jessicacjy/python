package JAVA_8;

import java.util.ArrayList;
import java.util.List;

public class StreamTesterII {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Widget> widgets = new ArrayList<Widget>();
		
		widgets.add(new Widget(10.5,"RED"));
		widgets.add(new Widget(1.5,"RED"));
		widgets.add(new Widget(10.5,"GREEN"));
		widgets.add(new Widget(2.0,"RED"));
		widgets.add(new Widget(1.5,"YELLOW"));
		
		
		double sum = widgets.stream()
                .filter(w -> w.getColor() == "RED")
                .mapToDouble(w -> w.getWeight())
                .sum();
		
		System.out.println(sum);

	}

}

class Widget {
	private double Weight;
	private String Color;
	
	Widget (double w, String c) {
		this.Weight = w;
		this.Color = c;
	}
	
	
	public double getWeight() {
		return Weight;
	}

	public String getColor() {
		return Color;
	}

	public String toString() {
		return "Widget wiegt: " + Weight + "     Color: " + this.Color;
	}
}

