package JAVA_8;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class StreamTesterI {
	public static void main(String[] args) {
		IntStream.range(1, 11)
		.forEach((s) -> System.out.println(s));
		//.forEach(System.out::println);
				
		System.out.println("----------------------------------");
		
		List<Integer> numbers = Arrays.asList(3, 2, 2, 3, 7, 3, 5);
		//get list of unique squares
		List<Integer> squaresList = numbers.stream().map( i -> i*i).distinct().collect(Collectors.toList());
		squaresList.stream().forEach((s) -> System.out.println(s));
	}
}
