package JAVA_8;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Random;
import java.util.stream.IntStream;
//import java.util.stream.Stream;

public class StreamTester {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		IntStream.range(1, 11).forEach(System.out::println);
		//Stream<Integer> s;
		Files.list(Paths.get(".")).forEach(System.out::println);
		
		Random rnd = new Random();
		rnd.ints().limit(10).forEach(System.out::println);
		rnd.ints().limit(10).sorted().forEach(System.out::println);
	}
	

}

