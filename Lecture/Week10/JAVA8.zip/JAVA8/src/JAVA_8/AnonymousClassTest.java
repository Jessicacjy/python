package JAVA_8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.OptionalDouble;
import java.util.stream.IntStream;

interface HelloWorld {
	void greet();
}

public class AnonymousClassTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Anonymous Class
		HelloWorld x = new HelloWorld() {
			public void greet() {
				System.out.println("Hello World!");
			}
		};
		x.greet();	
		
		//Lambda and function refrence
		List<String> lines = Arrays.asList("AA", "AAAA", "A", "AAA");
		lines.sort((String s1, String s2) -> s1.length() - s2.length());
		System.out.println(lines);
		//Arrays.sort(strArray,(String s1, String s2) -> s2.length() - s1.length());
		
		
		//Optional
		IntStream.range(1, 11)
			.forEach(System.out::println);
		IntStream is = IntStream.range(1, 11);
		OptionalDouble od = is.average();
		System.out.println(od);
		
	}
	
	
}


