package JAVA_8;

public class DefaultTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyInterface obj = new MyInterface() {
			public void talk() {
				System.out.println("Talking ... ");
			}
		};
		
		obj.greet();
		obj.talk();
	}

}
interface MyInterface {
	default void greet() {
		System.out.println("Hi ... ");
	};
	void talk();
}
