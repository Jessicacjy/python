package JAVA_8;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating an ActionListener
		// Java 7
		ActionListener al = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println(e.getActionCommand());
			}
		};
		// Java 8
		ActionListener al8 = e -> System.out.println(e.getActionCommand());
		
		List<String> list = Arrays.asList("AA", "AAAA", "A", "AAA");
		//Printing out a list of Strings
		// Java 7
		for (String s : list) {
		    System.out.println(s);
		}
		//Java 8
		list.forEach(System.out::println);
		
		
		//Sorting a list of Strings
		// Java 7
		Collections.sort(list, new Comparator<String>() {
			@Override
			public int compare(String s1, String s2) {
				return s1.length() - s2.length();
			}
		});
		//Java 8
		Collections.sort(list, (s1, s2) -> s1.length() - s2.length());
		// or
		list.sort(Comparator.comparingInt(String::length));
	}

}
