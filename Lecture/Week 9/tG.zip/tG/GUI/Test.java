package GUI;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Test {

	private JFrame frmMyFirstApplication;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Test window = new Test();
					window.frmMyFirstApplication.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Test() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmMyFirstApplication = new JFrame();
		frmMyFirstApplication.setTitle("My First Application");
		frmMyFirstApplication.setBounds(100, 100, 738, 412);
		frmMyFirstApplication.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmMyFirstApplication.getContentPane().setLayout(null);
		
		JLabel lblEnterANumber = new JLabel("Enter a number between (0 and 100)");
		lblEnterANumber.setBounds(12, 13, 274, 50);
		frmMyFirstApplication.getContentPane().add(lblEnterANumber);
		
		textField = new JTextField();
		textField.setBounds(234, 27, 116, 22);
		frmMyFirstApplication.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Try!");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textField.setText("90");
			}
		});
		btnNewButton.setToolTipText("Try Me .......");
		btnNewButton.setBounds(373, 26, 97, 25);
		frmMyFirstApplication.getContentPane().add(btnNewButton);
	}
}
