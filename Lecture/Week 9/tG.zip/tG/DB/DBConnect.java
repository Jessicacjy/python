package DB;

import java.sql.*;

public class DBConnect {

		private Connection con;

		
		public DBConnect() {
			try{
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/world?autoReconnect=true&useSSL=false","root","sasa");
				
				
			} catch(Exception ex) {
				System.out.println("Error: " + ex);
			}
		}
		
		public void getData() {
			try {
				Statement st;
				ResultSet rs;
				
				String query = "select * from phones";
				st = con.createStatement();
				rs = st.executeQuery(query);
				
				System.out.println("Records from database");
				while (rs.next()) {
					String name = rs.getString("name");
					String phone = rs.getString("phone");
					System.out.println(name + "----" + phone);
				}
			} catch(Exception ex) {
				System.out.println("Error: " + ex);
			}
		}
}
