package PARALLEL4;

import java.io.FileInputStream;
import java.util.Scanner;
import java.io.FileNotFoundException;
//import java.util.concurrent.ExecutorService;
//import java.util.concurrent.Executors;
/**
   Finds a target string from a file.  Then, the program will print out the
   line contains the target string.
*/
public class Find
{
   public static void main(String argv[]) throws InterruptedException
   {
	   long startTime,endTime;
	  String files[] = {"file1.txt","file2.txt","file3.txt","file4.txt","file5.txt","file6.txt","file7.txt","file8.txt"};
//Seq
	  startTime = System.currentTimeMillis();
		 
	  for (int i = 1; i <= files.length; i++)
      {
		  FindRunnable finder = new FindRunnable("computer", files[i-1]);
		  finder.FileSearch();
      }
      endTime = System.currentTimeMillis();
      System.out.println("Seq. Search: " + (endTime-startTime)/1000.0);
  


//Parallel 

		  Thread t[] = new Thread[8];
		  startTime = System.currentTimeMillis();
	      for (int i = 1; i <= files.length; i++)
	      {
	         FindRunnable finder = new FindRunnable("computer", files[i-1]);
	         t[i-1] = new Thread(finder);
	         t[i-1].start();
	      }
	      for (int i = 0; i < files.length; i++)
	    	  t[i].join();
	      endTime = System.currentTimeMillis();
	      System.out.println("Parallel Search: " + (endTime-startTime)/1000.0);
  }
}


/**
   Finds a target string from a file.  Then, the program will print out the
   line contains the target string.
*/
class FindRunnable implements Runnable
{
   private String target;
   private String filename;

   /**
       Constructs a FindRunnable object with a target string and file name.
       @param aTarget the target string that needs to be search
       @param aFilename the file name that needs to count word
   */
   public FindRunnable(String aTarget, String aFilename)
   {
      target = aTarget;
      filename = aFilename;
   }

   public void run()
   {
	   FileSearch(); 
   }
   
   public void FileSearch()
   {
	   int lineCount = 0;
      try
      {
         Scanner in = new Scanner(new FileInputStream("C:\\NWU\\MSiA 2016\\JavaSample\\OOP\\src\\PARALLEL4\\" + filename));
         
         while (in.hasNextLine())
         {  
            String line = in.nextLine();
            if ((line.indexOf(target)) != -1)
            {
            	lineCount++;
            }
            for (int j = 0; j < 10_000_000; j++)
            	lineCount = lineCount;
	            /*try
	            {
	               Thread.sleep(1);         
	            }
	            catch (InterruptedException exception)
	            {
	            }*/
         }
         System.out.println(filename + ": " + lineCount);
         in.close();
      } 
      catch (FileNotFoundException e)
      {
         System.out.println(filename + " not found!");
      }
   }
}