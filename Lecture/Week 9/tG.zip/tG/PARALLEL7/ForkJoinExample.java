package PARALLEL7;

import java.security.SecureRandom;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.RecursiveTask;

public class ForkJoinExample {
    private static final SecureRandom RANDOM = new SecureRandom();

    /**
     * Generate random unordered numbers of given size
     *
     * @param size size of array to generate
     * @return array of random numbers of the given size
     */
    public static int[] generateNumbers(int size) {
        int[] numbers = new int[size];
        for(int i=0; i < size ; i++) {
            numbers[i] = RANDOM.nextInt(Integer.MAX_VALUE);
        }
        return numbers;
    }

    /**
     * Finds the max in an array by iterating over all elements
     *
     * @param numbers array in which to find the max element
     * @return the max element in the array of numbers
     */
    private static int findMax(int[] numbers) {
        int max = numbers[0];
        for(int i = 1; i < numbers.length; i++) {             
            if (numbers[i] > max) {
                max = numbers[i];
            }
        }
        return max;
    }

    /**
     * A utility method to print time taken for an operation
     *
     * @param caption the caption to display
     * @param startTime the start time of an operation. Should be result of System.nanoTime().
     */
    private static void printTimeTaken(String caption, long startTime) {
        long elapsedTime = System.nanoTime() - startTime;
        long elapsedMillis = TimeUnit.MILLISECONDS.convert(elapsedTime, TimeUnit.NANOSECONDS);
        System.out.println(String.format("%s : Time taken %,d milliseconds", caption, elapsedMillis));
    }

    public static void main(String[] args) {
        //Let us find a max in an array of 200 million random integers
        int size = 200_000_000; //_000;

        long startTime = System.nanoTime();
        int[] numbers = generateNumbers(size);
        printTimeTaken("Generating numbers",startTime);


        //Now we use the RecursiveTask
        MaxSearchTask task = new MaxSearchTask(numbers);
        startTime = System.nanoTime();
        //Calling invoke (supported in JDK8) on this task will use builtin ForkJoinPool "commonPool"
        Integer result = (Integer) task.invoke();
        printTimeTaken("Finding max using fork/join", startTime);
        System.out.println(String.format("The maximum number found is %,d in an array of %,d numbers", result,size));
 
        //For a quick comparison, first we find the maximum in a single thread and then find the maximum using ForkJoinPool

        //Find the max by iterating over the complete array
        startTime = System.nanoTime();
        int m = findMax(numbers);
        printTimeTaken("Finding max in a single thread",startTime);
        System.out.println(String.format("The maximum number found is %,d in an array of %,d numbers", m, size));
    }
}



class MaxSearchTask extends RecursiveTask<Object> {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int[] numbers;
    private int startIndex;
    private int endIndex;
    private int taskSize = 50_000;

    public MaxSearchTask(int[] numbers) {
        this(numbers, 0, numbers.length);
    }

    public MaxSearchTask(int[] numbers, int startIndex, int endIndex) {
        this.numbers = numbers;
        this.startIndex = startIndex;
        this.endIndex = endIndex;
    }

    @Override
    protected Integer compute() {
        if ((endIndex - startIndex) <= taskSize) {             
              //We reached a problem of size below which we do not intend to divide            
              return findMax(startIndex, endIndex);         
        } else {             
             int mid = startIndex + (endIndex - startIndex) / 2 ;                         
             MaxSearchTask leftTask = new MaxSearchTask(numbers, startIndex, mid);             
             MaxSearchTask rightTask = new MaxSearchTask(numbers, mid, endIndex);             
             //asynchronously execute both left and right tasks in the pool the current task is running in             
             leftTask.fork();             
             rightTask.fork();             
             //wait for the left half result             
             int leftResult = (int) leftTask.join();             
             //wait for the right half result             
             int rightResult = (int) rightTask.join();             
             return leftResult > rightResult ? leftResult : rightResult;
        }
    }

    /**
     * Called to find the maximum integer that can be found in the range.
     *
     * @param start start index (inclusive)
     * @param end   end   index (exclusive)
     * @return max integer in range
     */
    private int findMax(int start, int end) {
        int max = numbers[start];
        //i starts with next index
        for(int i = start + 1; i < end; i++) {             
            if (numbers[i] > max) {
                max = numbers[i];
            }
        }
        return max;
    }
}