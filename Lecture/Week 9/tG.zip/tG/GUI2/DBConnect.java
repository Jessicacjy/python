package GUI2;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.DefaultListModel;
import com.mysql.jdbc.PreparedStatement;

public class DBConnect {

		private Connection con;
		private Statement st;
		private ResultSet rs;

		public DBConnect() {
			try{
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/world?autoReconnect=true&useSSL=false","root","sasa");
				st = con.createStatement();

				
			} catch(Exception ex) {
				System.out.println("Error: " + ex);
			}
		}
		
		private int getNextId() {
			try {
				String sql = "select max(id)+1 As id from phones";
				rs = st.executeQuery(sql);
				System.out.println("Records from database");
				rs.next();
				int id = rs.getInt("id");
				return id;				
			} catch(Exception ex) {
				System.out.println("Error: " + ex);
				return -1;
			}		
		}
		
		public void addContact(String name, String phone)
		{
			try {
				int id = getNextId();
				String sql = "insert into phones"
						+ "(id,name,phone) VALUES"
						+ "(?,?,?)";
				PreparedStatement pst = (PreparedStatement) con.prepareStatement(sql);
				pst.setInt(1, id);
				pst.setString(2, name);
				pst.setString(3, phone);
				pst.executeUpdate();				
			} catch(Exception ex) {
				System.out.println("Error: " + ex);
			}
		}
		
		public void updateContact(int id,String name, String phone)
		{
			try {
				String sql = "update phones "
						+ "set name = '" + name + "', "
						+ "phone = '" + phone + "' "
						+ "where id = ? ";
				PreparedStatement pst = (PreparedStatement) con.prepareStatement(sql);
				pst.setInt(1, id);
				pst.executeUpdate();				
			} catch(Exception ex) {
				System.out.println("Error: " + ex);
			}
		}
		
		public void deleteContact(int id)
		{
			try {
				
				String sql = "delete from phones where id = ?";
				PreparedStatement pst = (PreparedStatement) con.prepareStatement(sql);
				pst.setInt(1, id);
				pst.executeUpdate();				
			} catch(Exception ex) {
				System.out.println("Error: " + ex);
			}
		}
		
		public DefaultListModel<String> getData() {
			DefaultListModel<String> DLM = new DefaultListModel<String>();
			try {
				String query = "select * from phones";
				rs = st.executeQuery(query);
				System.out.println("Records from database");
				while (rs.next()) {
					String id = rs.getString("id");
					String name = rs.getString("name");
					String phone = rs.getString("phone");
					String element = id + ";" + name + ";" + phone;
					DLM.addElement(element);
				}
			} catch(Exception ex) {
				System.out.println("Error: " + ex);
			}
			return DLM;
		}
}

