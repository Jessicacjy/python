package GUI2;
import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.ListSelectionModel;
import javax.swing.JCheckBox;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class MyFirstApp {

	private JFrame frmPhoneDirectory;
	private JTextField textPhone;
	private JTextField textName;
	private JTextField textId;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MyFirstApp window = new MyFirstApp();
					window.frmPhoneDirectory.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MyFirstApp() {
		initialize();

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmPhoneDirectory = new JFrame();
		frmPhoneDirectory.addWindowListener(new WindowAdapter() {
			@Override
			public void windowOpened(WindowEvent arg0) {
			}
		});
		frmPhoneDirectory.setTitle("Phone Directory");
		frmPhoneDirectory.setBounds(100, 100, 705, 456);
		frmPhoneDirectory.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmPhoneDirectory.getContentPane().setLayout(null);
		
		JLabel lblName = new JLabel("Name:");
		lblName.setBounds(48, 77, 56, 16);
		frmPhoneDirectory.getContentPane().add(lblName);
		
		JLabel lblPhone = new JLabel("Phone:");
		lblPhone.setBounds(48, 109, 56, 16);
		frmPhoneDirectory.getContentPane().add(lblPhone);
		
		textPhone = new JTextField();
		textPhone.setBounds(102, 106, 267, 22);
		frmPhoneDirectory.getContentPane().add(textPhone);
		textPhone.setColumns(10);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DBConnect myDB = new DBConnect();
				myDB.addContact(textName.getText(), textPhone.getText());
			}
		});
		btnAdd.setBounds(48, 153, 97, 25);
		frmPhoneDirectory.getContentPane().add(btnAdd);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(48, 192, 591, 186);
		frmPhoneDirectory.getContentPane().add(scrollPane);
		
		JList<String> list = new JList<String>();
		scrollPane.setViewportView(list);
		list.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				System.out.println("Element: " + list.getSelectedValue());
			}
		});
		
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DBConnect myDB = new DBConnect();
				String element[] = list.getSelectedValue().split(";");
				System.out.println("Element: " + element[0]);
				myDB.deleteContact(Integer.parseInt(element[0]));
			}
		});
		btnDelete.setBounds(155, 153, 97, 25);
		frmPhoneDirectory.getContentPane().add(btnDelete);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DBConnect myDB = new DBConnect();
				myDB.updateContact(Integer.parseInt(textId.getText()),textName.getText(), textPhone.getText());
			}
		});
		btnUpdate.setBounds(370, 153, 97, 25);
		frmPhoneDirectory.getContentPane().add(btnUpdate);
		
		JButton btnLoad = new JButton("Load");
		btnLoad.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String element[] = list.getSelectedValue().split(";");
				textId.setText(element[0]);
				textName.setText(element[1]);
				textPhone.setText(element[2]);
			}
		});
		btnLoad.setBounds(264, 153, 97, 25);
		frmPhoneDirectory.getContentPane().add(btnLoad);
		
		JButton btnRefreshList = new JButton("Refresh List");
		btnRefreshList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DBConnect myDB = new DBConnect();
				list.setModel(myDB.getData());
			}
		});
		btnRefreshList.setBounds(525, 153, 114, 25);
		frmPhoneDirectory.getContentPane().add(btnRefreshList);
		
		textName = new JTextField();
		textName.setBounds(102, 74, 267, 22);
		frmPhoneDirectory.getContentPane().add(textName);
		textName.setColumns(10);
		
		JLabel lblId = new JLabel("Id");
		lblId.setBounds(48, 48, 44, 16);
		frmPhoneDirectory.getContentPane().add(lblId);
		
		textId = new JTextField();
		textId.setEnabled(false);
		textId.setText("Id");
		textId.setBounds(102, 42, 116, 22);
		frmPhoneDirectory.getContentPane().add(textId);
		textId.setColumns(10);
		
		JLabel lblMyFirstGui = new JLabel("Type");
		lblMyFirstGui.setBounds(368, 69, 73, 32);
		frmPhoneDirectory.getContentPane().add(lblMyFirstGui);
		
		JComboBox cbType = new JComboBox();
		cbType.setModel(new DefaultComboBoxModel(new String[] {"Cell", "Home", "Work"}));
		cbType.setBounds(453, 74, 170, 22);
		frmPhoneDirectory.getContentPane().add(cbType);
		
		JLabel lblHi = new JLabel("New label");
		lblHi.setBounds(453, 27, 126, 16);
		frmPhoneDirectory.getContentPane().add(lblHi);
		
		JButton btnSayHi = new JButton("Say Hi");
		btnSayHi.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				lblHi.setText("Hi MSiA");
			}
		});
		btnSayHi.setBounds(314, 23, 97, 25);
		frmPhoneDirectory.getContentPane().add(btnSayHi);
		
		
		DBConnect myDB = new DBConnect();
		list.setModel(myDB.getData());

	}
}
