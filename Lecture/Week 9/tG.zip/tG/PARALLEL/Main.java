package PARALLEL;

import java.util.ArrayList;
public class Main {
    static final int MAX = 10000000;
    static final int THREADS = Runtime.getRuntime().availableProcessors();
    static final int ARRINITSIZE = 100000;
    static ArrayList<Integer> primes = new ArrayList<Integer>(ARRINITSIZE);
    
    public static void main(String[] args) throws Exception {
	Thread[] t = new Thread[THREADS];
	PrimeRun.m = new Monitor();
	
	for (int i=0; i<THREADS; i++) {
	    t[i] = new Thread(new PrimeRun(i) );
	    t[i].start();
	}

	// wait for threads to finish
	for (int i=0; i<THREADS; i++)
	    t[i].join();

	// print out all primes
	// NOTE: they will be out of order because of random thread scheduling 
	for (int n : primes)
	    System.out.println("" + n + " ");
	System.out.println();
    }
    
    public static boolean isPrime(int n) {
	if (n == 2 || n == 3 || n == 5) return true;
	if (n <= 1 || (n&1) == 0) return false;

	for (int i = 3; i*i <= n; i += 2)
	    if (n % i == 0) return false;

	return true;
    }

    public synchronized static void addPrime(int n) {
	primes.add(n);
    }

}

class PrimeRun implements Runnable {
    public static Monitor m;
    final int ID;
    public PrimeRun(int i) {
	ID = i;
    }

    public void run() {
	for(int i=0; i < Main.MAX; i++) {
	    if(i % Main.THREADS == ID)
		if(Main.isPrime(i)) 
		    m.addPrime(i);
	}
    }
}

class Monitor {
    public synchronized void addPrime(int n) {
	Main.addPrime(n);
    }
}
