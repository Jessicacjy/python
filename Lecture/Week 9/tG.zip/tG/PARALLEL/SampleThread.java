package PARALLEL;

public class SampleThread {

	public static void main(String[] args) throws InterruptedException {
		aTask t1 = new aTask(100);
		
		aTask t2 = new aTask(200);
		t1.start();
		//t1.join(); //<----------- order
		t2.start();
	}

}

class aTask extends Thread{
	private int myID;

	public aTask(int id){
		this.myID = id;
	}
	
	public void run(){
		for (int i=0;i<10;i++) {
			System.out.println("<ID: " + myID + ">" + i);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {}
		}
	}
}
