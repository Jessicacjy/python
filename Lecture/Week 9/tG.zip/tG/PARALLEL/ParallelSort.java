	package PARALLEL;

	import java.util.Arrays;
	import java.util.Random;


	public class ParallelSort {
	   final static int ARR_SIZE = 10 * 1024 *1024;    // 10 MB
	   final static int LOOPS = 100;                  // execute 100 times

	   public static void main(String[] args) {

	      // create an array with random numbers
	      int[] array = new int[ARR_SIZE];
	      Random rand = new Random(1);  // make sure to use the same random sequence each time, to ensure reproduceability
	      for (int i = 0;  i < array.length;  i++) {
	         array[i] = rand.nextInt(9999999);
	      }


	      long startTime = System.currentTimeMillis();
		     
	      for (int i = 0;  i < LOOPS;  i++) {
	         int[] toSort = Arrays.copyOf(array, array.length);
	         Arrays.sort(toSort);
	      }

	      long endTime = System.currentTimeMillis();
		  System.out.println("Normal sort:: " + (endTime-startTime)/1000.0);

		  startTime = System.currentTimeMillis();
	      for (int i = 0;  i < LOOPS;  i++) {
	         int[] toSort = Arrays.copyOf(array, array.length);
	         Arrays.parallelSort(toSort);
	      }

	      endTime = System.currentTimeMillis();
		  System.out.println("Parallel sort: " + (endTime-startTime)/1000.0);
	   }
	}
