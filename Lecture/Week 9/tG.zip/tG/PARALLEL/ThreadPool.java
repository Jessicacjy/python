package PARALLEL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ThreadPool {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExecutorService es = Executors.newFixedThreadPool(2);
		es.execute(new myTask(1));
		es.execute(new myTask(2));
		es.execute(new myTask(3));
/* <-------------------	*/
		es.execute(new myTask(4));
		es.execute(new myTask(5));
		es.execute(new myTask(6));

		es.shutdown();
	}

}

class myTask implements Runnable {
	private int myID;
	
	public void run(){
		System.out.println("Task: " + myID + " Started");
		for (int i=0;i<5;i++) {
			System.out.println("<ID: " + myID + ">" + i);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {}
		}
		System.out.println("Task: " + myID + " Ended");
	}
	
	public myTask(int id){
		this.myID = id;
	}
}