package PARALLEL;

import java.util.concurrent.ExecutorService;  
import java.util.concurrent.Executors;  

class WorkerThread implements Runnable {  
    private String message;  
    public WorkerThread(String s){  
        this.message=s;  
    }  
     public void run() {  
        System.out.println(Thread.currentThread().getName()+" (Start) message = "+message);  
        processmessage();//call processmessage method that sleeps the thread for 2 seconds  
        System.out.println(Thread.currentThread().getName()+" (End)");//prints thread name  
    }  
    private void processmessage() {  
        //try {  
        	for (int i = 0; i<100_0000;i++)
        		isPrime(i);
        	//Thread.sleep(2000);  
        			//} //catch (InterruptedException e) { e.printStackTrace(); }  
    }  
    private  boolean isPrime(int n) {
    	if (n == 2 || n == 3 || n == 5) return true;
    	if (n <= 1 || (n&1) == 0) return false;

    	for (int i = 3; i*i <= n; i += 2)
    	    if (n % i == 0) return false;

    	return true;
    }
}  

public class ExecuterService {  
    public static void main(String[] args) {  
       ExecutorService executor = Executors.newFixedThreadPool(2);//creating a pool of 5 threads  
       for (int i = 0; i < 100; i++) {  
           Runnable worker = new WorkerThread("" + i);  
           executor.execute(worker);//calling execute method of ExecutorService  
         }  
       executor.shutdown();  
       while (!executor.isTerminated()) {   }  
 
       System.out.println("Finished all threads");  
   }  
}
