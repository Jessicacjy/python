package com.msi.sample;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JFrame;
import java.util.Scanner;


@SuppressWarnings("serial")
public class DrawPolynomial  extends JFrame {	
	public DrawPolynomial() 
	{
	    //super("Class Paint");                  
	    setSize(800, 800);    
	    setLayout(null);
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setVisible(true);
	}

	public void paint(Graphics g) 
	{
	    super.paint(g);
	    
	    Scanner in = new Scanner(System.in);
	    
	    System.out.println("Enter Grid Dimension:");
	    
	    int GridDimension = 6;
	    
	    //GridDimension = in.nextInt();
	    
	    
	    for (int row = 0;row<GridDimension;row++)
	    {
	    	for (int column = 0;column<GridDimension;column++)
		    {
	    		if (row < GridDimension/2 && column < GridDimension/2)
	    		{
	    			g.setColor(Color.green);
	    			g.fillOval(row*60 + 50,column*60 + 50, 50,50);
	    		}
	    		else if (row >= GridDimension/2 && column >= GridDimension/2)
	    		{
	    			g.setColor(Color.red);
	    			g.fillOval(row*60 + 50,column*60 + 50, 50,50);
	    		}
	    		else
	    		{
	    			g.setColor(Color.BLACK);
	    			g.fillOval(row*60 + 50,column*60 + 50, 50,50);	    		
	    		}
		    }
	    }
	}
}
