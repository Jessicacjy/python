package com.msi.sample;

public class FaceDrawing  {

	public static void main(String[] args) {
		new DrawPolynomial();
	}
}



