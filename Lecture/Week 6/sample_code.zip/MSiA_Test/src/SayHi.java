import java.util.Scanner;


public class SayHi {
	
	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		
		System.out.println("Enter Your Name: ");
		String name = in.next();
		
		System.out.print("Hi ");
		System.out.println(name);
		
		int w = Add2(3,5);
		System.out.print(w);
		System.out.println((int) Math.sqrt(100));
		
		double salary = 16500.0;
		
		System.out.printf("%-20s---%10.2f",name, salary);
		in.close();
	}
	
	public static int Add2(int x,int y){
		int z = x + y;
		return z;
	}
}
/*
private static class myCalc2 {
	public int Add(int x,int y) {
		return x+y;
	}
	public int Multiply(int x,int y) {
		return x*y;
	}
	public int Divide(int x,int y) {
		return x/y;
	}
}
*/


