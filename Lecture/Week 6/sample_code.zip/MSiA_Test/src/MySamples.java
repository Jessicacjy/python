
public class MySamples {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//boxString("I like Java");
		
		MyLib ref = new MyLib();
		ref.boxString("Test String");
		ref.ReverseIt("Hello World");
	}
/*	
	public static void boxString(String str)
	{
	  int n = str.length();
	  for (int i = 0; i < n + 2; i++) 
	    { System.out.print("-"); }
	  System.out.println();
	  System.out.println("!" + str + "!");
	  for (int i = 0; i < n + 2; i++) 
	    { System.out.print("-"); }
	  System.out.println();
	}
	*/
}

class MyLib {
	//public static void boxString(String str)
	public void boxString(String str)
	{
	  int n = str.length();
	  for (int i = 0; i < n + 2; i++) 
	    { System.out.print("-"); }
	  System.out.println();
	  System.out.println("!" + str + "!");
	  for (int i = 0; i < n + 2; i++) 
	    { System.out.print("-"); }
	  System.out.println();
	}
	public static void ReverseIt(String s) {
	    // Loop backwards through the array of arguments
	    for(int i = s.length()-1; i >= 0; i--) {
	        System.out.print(s.charAt(i));
	    }
	    System.out.print(" ");  // add a space at the end of each argument
	    System.out.println();     // and terminate the line when we're done.
	}
}
/*
public class Factorial
{
	public static void main(String[] args)
	{	final int NUM_FACTS = 100;
		for(int i = 0; i < NUM_FACTS; i++)
			System.out.println( i + "! is " + factorial(i));
	}
	
	public static int factorial(int n)
	{	int result = 1;
		for(int i = 2; i <= n; i++)
			result *= i;
		return result;
	}
}

public class StringExample
{	public static void main(String[] args)
	{	String s1 = "Computer Science";
		int x = 307;
		String s2 = s1 + " " + x;
		String s3 = s2.substring(10,17);
		String s4 = "is fun";
		String s5 = s2 + s4;
		
		System.out.println("s1: " + s1);
		System.out.println("s2: " + s2);
		System.out.println("s3: " + s3);
		System.out.println("s4: " + s4);
		System.out.println("s5: " + s5);
		
		//showing effect of precedence
		
		x = 3;
		int y = 5;
		String s6 = x + y + "total";
		String s7 = "total " + x + y;
		String s8 = " " + x + y + "total";
		System.out.println("s6: " + s6);
		System.out.println("s7: " + s7);
		System.out.println("s8: " + s8);
	}
}

public class Factorial {
  
  public static int factorial(int x) {
    int fact = 1;
    for(int i = 2; i <= x; i++)    // loop
      fact *= i;                   // shorthand for: fact = fact * i;
    return fact;
  }
}

public class Factorial2 {
	  public static long factorial(long x) {
	    if (x == 1) return 1;
	    else return x * factorial(x-1);
	  }
	}
*/