
public class Reverse_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String x;
		x = ReverseIt("Hi Java");
		System.out.println(x);
		
		boxString("Today is a Good day");
		
		System.out.println(Factorial(5));
		
		fizz_buzz(50,3,6);
	}
	
	public static String ReverseIt(String s) {
	    // Loop backwards through the array of arguments
		String result = "";
	    for(int i = s.length()-1; i >= 0; i--) {
	        result = result + s.charAt(i);
	    }
	    return result;
	}
	
	public static void boxString(String str)
	{
	  int n = str.length();
	  for (int i = 0; i < n + 2; i++) 
	    { System.out.print("-"); }
	  System.out.println();
	  System.out.println("!" + str + "!");
	  for (int i = 0; i < n + 2; i++) 
	    { System.out.print("-"); }
	  System.out.println();
	}

	public static int Factorial(int n)
	{	
		if ( n == 1) return 1;
		else
			return n * Factorial(n-1);
	}
	
	public static void fizz_buzz(int total,int fizz,int buzz ) {   
		for(int i = 1; i <= total; i++) {                    // count from 1 to 100
			if (((i % fizz) == 0) && ((i % buzz) == 0))            // A multiple of both?
				System.out.print("fizzbuzz");    
			else if ((i % fizz) == 0) System.out.print("fizz"); // else a multiple of 5?
			else if ((i % buzz) == 0) System.out.print("buzz"); // else a multiple of 7?
			else System.out.print(i);                        // else just print it
			System.out.print(" "); 
	    }
	    System.out.println();
	  }
}
