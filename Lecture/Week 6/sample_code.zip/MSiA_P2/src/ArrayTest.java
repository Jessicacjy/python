
import java.util.Scanner;

public class ArrayTest {

	public static void main2(String[] args) {
		// TODO Auto-generated method stub
		String[] names = {"A","B","C"};
		
		for (int index = 0; index < names.length; index++)
		{
			System.out.println(names[index]);
		}
	}

	public static void main(String[] args) {
		Scanner inp = new Scanner(System.in);
		int grade;
		int max = 0;
		do 
		{
			System.out.println("Enter a grade:");
			grade = inp.nextInt();
			if (grade > max)
				max = grade;
		}
		while (grade != -1);
		System.out.println(max);
	}
}
